export const GET_DATA ='GET_DATA'
export const GET_DATA_SUCCESS ='GET_DATA_SUCCESS'
