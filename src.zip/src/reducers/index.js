import {combineReducers} from "redux"
import getDataReducer from "./getData"

export const rootReducer = combineReducers ({
    getDataReducer
})

